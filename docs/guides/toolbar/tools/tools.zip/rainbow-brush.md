![Icon]

The same as the brush, though it cycles the colors while you paint.

Intended to be a tool to test colors in the first iterations of Pixly, it was just too awesome to be left out of the final release. It's also a good tool to set to when you want to let kids draw stuff on your phone.

### Settings

+ Change color by

  You can choose if the cycling will be done for each *pixel*, by the speed of the *motion* or even by *time*.

+ Speed

  How fast should the colors change by iteration?

+ Hue, Saturation and Brightness

  The hue the brush will start at on the next stroke, and the saturation and brightness the colors will have.
  

<img class="gfyitem" data-id="WideeyedDistantAsianporcupine"/>

[Icon]: /guides/guides/toolbar/tools/icons/rainbowBrush.png
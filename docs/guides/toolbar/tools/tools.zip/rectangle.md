![Icon]

Drag to draw rectangles and quads!

### Settings

+ Perfect Square
  
  It doesnt matter how you drag, it will always make a perfect square.

+ Fill
  
  The retangle will come out filled

<img class="gfyitem" data-id="TautNextGaur"/>

[Icon]: /guides/guides/toolbar/tools/icons/rect.png
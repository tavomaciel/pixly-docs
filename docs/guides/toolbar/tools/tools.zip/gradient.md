![Icon]

If you used this tool on GIMP or Photoshop, you know what it is about. It does the same, but the amount of colors is limited, and you can decide how much dithering it will include.

The gradient will be applied with the [primary and secondary colors].

By default, it is limited to 4 colors, and the dithering is set to 60% on the transitions.

> Keep in mind: It will be applied on the entire artboard, unless you have something [selected], which will then, be limited to that selection.

### Settings

+ Color Limit

  Unlimited colors? 2? 16? You choose!

+ Dithering

  How much dithering should be applied? Default is 60%, and 10%~20% is another good range of values for a more retro feel.

+ Dither pattern

  A shortcut to change the [pattern] of the dither.
  

<img class="gfyitem" data-id="MediumDisguisedJaeger"/>
(This sample had 4 colors and dithering set to 12%)

[Icon]: /guides/guides/toolbar/tools/icons/gradient.png
[pattern]: /guide/wiki/color-brush/brush/patterns
[primary and secondary colors]: /guide/wiki/color-brush/primary-secondary
[selected]: /guide/wiki/toolbar/tools/marquee
![Icon]

These tools help you placing text in the screen.

> This feature was recently added, so it's a little rough in the edges:
>
> Currently the only 3 fonts included are the ones that make up the whole pixly UI. Later it might support custom fonts.
> 
> You can scale nor rotate text right now. You might want to use the [free transform] operation to accomplish it.

### Place Text
![Icon place]

The text that is currently written will be stamped right under your finger.


### Write Text
![Icon write]

Change the text that is written to something else.


### Settings

+ Font

  Small, Normal and Narrow, are the current options for now.


<img class="gfyitem" data-id="ShimmeringAnimatedHawaiianmonkseal"/>

[Icon]: /guides/guides/toolbar/tools/icons/text.png
[Icon place]: /guides/guides/toolbar/tools/icons/placetext.png
[Icon write]: /guides/guides/toolbar/tools/icons/writetext.png
[free transform]: /guide/wiki/mainmenu/edit/free-transform
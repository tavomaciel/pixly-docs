![Icon]

Well... it draws lines.

### Settings

+ Snap

  Will snap the line to either 15º increments, to each integer tangent (for example, 2:1, or 5:2) or not even snap at all. Integer tangent is awesome for dimetric/isometric art!
  

<img class="gfyitem" data-id="CoolShallowBumblebee"/>

[Icon]: /guides/guides/toolbar/tools/icons/line.png
![Icon]

It's a tool that you can use it to pick colors, a easier way to do the same is to drag the color selector, but the picker will show you a more detailed result, and with customizable settings!

The picker auto-switches back to the last tool you used.

### Settings

+ Sample Mode

  The picker may pick colors only on the current layer, or the one above, the ones below, or all layers! The difference between _mixed_ and _separated_, is that if one layer has a semi-transparent color, the mixed mode will mix it with the colors below it before passing it to the picker, where the separated mode will get the color as is.

+ Pick Alpha

  If set to **No**, will ignore alpha completely, otherwise, will set the [opacity] while picking.
  

**TODO GFY**

[Icon]: /guides/guides/toolbar/tools/icons/color_picker.png
[opacity]: /guide/wiki/color-brush/opacity
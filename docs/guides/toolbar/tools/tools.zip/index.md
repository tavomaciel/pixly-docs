![Some common tools]

In Pixly, everything that can be accessed through the toolbar is considered to be a tool, and we currently have about 21 of these.

### Settings

Some tools can be customized or changed in the way they operate, if you find a tool like this (examples are the [Bucket fill] and [Line] tools, but there's more!), you can access its settings by tapping the icon which appears that **tool and a _screw driver_**:

![Settings entry]

If you touch it, you'll find out all the settings you can change for that selected tool.

Here's one sample for the [Bucket fill]:

![Settings sample]

### The tools themselves

If you want to know more about the tools, I'd recommend you to read the subpages of this guide. You can find them just at the right of this text, under the purple "Toolbar" line.

> Quick tip: You might want to keep in mind that most of the tools are affected by [color and brush] settings! Don't forget to check out that section of the guide!


[settings entry]: /guides/guides/toolbar/tools/settings.png
[settings sample]: /guides/guides/toolbar/tools/settings2.png
[some common tools]: /guides/guides/toolbar/tools/tools.png


[bucket fill]: /guide/wiki/toolbar/tools/bucket
[line]: /guide/wiki/toolbar/tools/line
[color and brush]: /guide/wiki/color-brush
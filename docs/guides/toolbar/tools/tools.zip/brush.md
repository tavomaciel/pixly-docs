![Icon]

The most common tool, and also the one which Pixly always starts with.

<img class="gfyitem" data-id="SnappyQuickIcterinewarbler"/>

[Icon]: /guides/guides/toolbar/tools/icons/pencil.png
![Icon]

Drag to draw ellipses and circles!

### Settings

+ Perfect Circle

  It doesnt matter how you drag, it will always make a perfect circle.

+ Fill

  The circle will come out filled
  

<img class="gfyitem" data-id="BaggyImmediateIlladopsis"/>

[Icon]: /guides/guides/toolbar/tools/icons/circle.png
![Icon]

It's a brush that will draw [patterns].

Some people like it for dithering!

### Settings

+ Pattern

  It's a shortcut to the brush [patterns] screen.

+ Invert Pattern

  What's transparent will be coloured, and vice-versa.
  

<img class="gfyitem" data-id="ApprehensiveFearfulGazelle"/>

[Icon]: /guides/guides/toolbar/tools/icons/stamp.png
[patterns]: /guide/wiki/color-brush/brush/patterns
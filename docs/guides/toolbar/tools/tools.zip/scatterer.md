![Icon]

It will scatter pixels under your finger, they may be all of the [selected color], or they may be of a range. The amount of pixels, and how often they are scattered can also be fully changed.

You may know it by the name **spray** on other art softwares, but on pixly it's so powerful that it needed a better name to suit what it does, so that's the **scatterer**

### Settings

+ Speed

  Also known as **amount**, it's how many pixels will be spilled by the scatterer each time it decides to paint.

+ Interval

  This decides how often the scatterer will paint during continuous strokes. Think of this as "How much does my finger have to move before the scatterer will paint again". 0 is immediately, 50 is after a big while.

+ Variation values

  These are how much will that parameter variate from the current color. This values count both up and down variation. E.g.: If my [selected color] has a hue of 130°, and I set the *Hue Variation* setting to 20°, then the scatterer will scatter colors with hue between 120° and 140° _( which is 130° +- (20°/2) )_. The same rule applies to the other parameters.
  

<img class="gfyitem" data-id="JauntyScalyAmericancicada"/>

[Icon]: /guides/guides/toolbar/tools/icons/scatter.png
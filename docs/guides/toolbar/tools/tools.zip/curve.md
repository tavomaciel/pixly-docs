![Icon]

Draw curves. Technically speaking, it draws cubic bezier curves.

The first drag will draw the line, the second will set the first anchor point, the third will set the second anchor point.

<img class="gfyitem" data-id="LimpingCourteousAfricancivet"/>

[Icon]: /guides/guides/toolbar/tools/icons/curve2.png
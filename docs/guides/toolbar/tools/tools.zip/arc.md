![Icon]

It draw arcs, it's the simpler version of the curve tool. Technically speaking, it draws quadratic bezier curves.

The first drag will draw the line, the second will make the curvature.

<img class="gfyitem" data-id="ArcticAdoredBuckeyebutterfly"/>

[Icon]: /guides/guides/toolbar/tools/icons/curve.png
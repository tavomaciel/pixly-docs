![Icon]

Tap a place and get it all flooded by a single color!

### Settings

+ Contiguous

  If set to **"No"**, will ignore all boundaries and edges, painting every color that is the same as the one you touched, no matter where it is. I.e., you turn it into a "replace color".

+ Apply pattern

  Instead of solid colors, will fill a [pattern]!

+ Invert pattern

  What is transparent will be coloured and vice-versa.


<img class="gfyitem" data-id="InexperiencedAncientDiplodocus"/>

[Icon]: /guides/guides/toolbar/tools/icons/rainbowBrush.png
[pattern]: /guide/wiki/color-brush/brush/patterns
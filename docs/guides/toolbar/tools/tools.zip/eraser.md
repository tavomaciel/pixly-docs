![Icon]

It's just like the brush, but the opposite.

In layers that have no [transparency], like the bottom layer of not-transparent projects, the eraser will paint the color that's not selected, i.e. if the primary color is selected, then the secondary color will be painted, and if the secondary color is selected, then the primary color will be painted.

In transparent layers the eraser will simply delete the pixels it passes through.

Keep in mind that [opacity] is also valid for the eraser.

<img class="gfyitem" data-id="MenacingSlimyDragonfly"/>

[Icon]: /guides/guides/toolbar/tools/icons/eraser.png

[transparency]: /guide/wiki/mainmenu/colors-filters/transparency
[opacity]: /guide/wiki/color-brush/opacity
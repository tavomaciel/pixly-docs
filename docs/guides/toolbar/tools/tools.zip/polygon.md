![Icon]

Put points, and a polygon will be filled for you.

*This tool will have a gfy after it gets out of experimental phase*

[Icon]: /guides/guides/toolbar/tools/icons/polygon.png